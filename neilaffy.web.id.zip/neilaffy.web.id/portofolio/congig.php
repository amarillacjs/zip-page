<?php
$db = new PDO('sqlite:../../amadb.db');

?>
