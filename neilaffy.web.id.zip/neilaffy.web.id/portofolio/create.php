<?php
session_start();
include "congig.php";
$subdomain = $_SESSION['subdomain'];
$sqlp = $db->prepare('SELECT count(port) AS port FROM ports ORDER BY port DESC LIMIT 1');
$sqlp->execute();
$rows = $sqlp->fetchAll(\PDO::FETCH_ASSOC);
$port = $rows[0]['port'];
if (!$subdomain) {
    echo "No Created!";
} else {
    if ($port > 10 && $port < 99) {
        $c = "60".$port;
    } elseif ($port > 100 && $port < 999) {
        $c = "6".$port;
    } elseif ($port > 1000 && $port < 9999) {
        $c = $port;
    } else {
        $c = "600".$port;
    }
    $sitesAvailable = "
    server {
       listen ".$c.";
       listen [::]:".$c.";
       
       server_name _;
       root /var/www/".$subdomain.";
       index index.html;

       location / {
              try_files \$uri \$uri/ =404;
      }
    }";
    
    $myfile = fopen($subdomain, "w");
    fwrite($myfile, $sitesAvailable);
    fclose($myfile);
    $sql = $db->query("INSERT INTO ports VALUES('$c','$subdomain')");
   if($sql){
    shell_exec('sudo mkdir -p /var/www/'.$subdomain.'/public_html');
    shell_exec('sudo mv '.$subdomain.' /etc/nginx/sites-available');
    shell_exec('sudo ln -sf /etc/nginx/sites-available/'.$subdomain.' /etc/nginx/sites-enabled');
    shell_exec('sudo service nginx reload');
    header('Location: cat.php');
   }
}
