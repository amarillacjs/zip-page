<?php
include "congig.php";
$sv = $db->query('SELECT * FROM ports');
$dbh = $sv->fetchAll(PDO::FETCH_ASSOC);

foreach ($dbh as $read){
    $subdomain = $read['subdomain'];
$tunnel = "
tunnel: ".$read['subdomain']."
credentials-file: /home/userland/.cloudflared/".$read['subdomain'].".json

ingress:

- hostname: ".$read['subdomain']."
service: http://localhost:".$read['port']."
- service: http_status:404
";
}
$myfiles = fopen(config.yml, "w");
fwrite($myfiles, $tunnel);
fclose($myfiles);
shell_exec('sudo rm -r ~/.cloudflared/config.yml');
shell_exec('sudo mv config.yml ~/.cloudflared');
shell_exec('sudo cloudflared tunnel route dns "'.$subdomain.'" "'.$subdomain.'"');
shell_exec('sudo cloudflared tunnel run "'.$subdomain.'"');
shell_exec('sudo service cloudflared restart');
header('Location: dashboard.php');