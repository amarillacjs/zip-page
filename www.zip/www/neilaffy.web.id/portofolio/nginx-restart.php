<?php
shell_exec('sudo service nginx restart  2>&1'); 
header('Location: dashboard.php');
?>
