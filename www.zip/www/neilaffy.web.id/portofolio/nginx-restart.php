<?php
shell_exec('sudo service nginx restart'); 
header('Location: dashboard.php');
?>
