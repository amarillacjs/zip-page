<?php
session_start();
if(!$_SESSION['success']){
    header('Location: login.php');
}
$subdomain = $_SESSION['subdomain'];
$ports = $_SESSION['ports'];
$tunnel = "
tunnel: ".$subdomain."
ingress:
  - hostname: ".$subdomain."
    service: http://localhost:".$ports."
  - service: http_status:404
";
$myfiles = fopen($subdomain.yml, "w");
fwrite($myfiles, $tunnel);
fclose($myfiles);

shell_exec('sudo mv '.$subdomain.'.yml ~/.cloudflared');
shell_exec('sudo cloudflared tunnel route dns "'.$subdomain.'" "'.$subdomain.'"');
shell_exec('sudo cloudflared tunnel run "'.$subdomain.'"');
header('Location: dashboard.php');