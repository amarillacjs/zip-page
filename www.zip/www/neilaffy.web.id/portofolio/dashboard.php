<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
unset($_SESSION['subdomain']);
if (!$_SESSION['success']) {
    header('Location: login.php');
}
include "congig.php";
if (isset($_POST['continue'])) {
    $name = htmlspecialchars($_POST['namePlan']);
    $planName = htmlspecialchars($_POST['plan']);
    $subdomain = strtolower(htmlspecialchars($_POST['subdomain'].".neilaffy.web.id"));
    $id = $_SESSION['success'];
    $names = $id ."=".$name;
    if ($planName == "Plan1") {
        $price = "400000";
        $domain = "10";
    } else if ($planName == "New") {
        $price = "0";
        $domain = "1";
    } else {
        $price = "0";
        $domain = "1";
    }
    $coal = rand(0, 99999999);
    $ex = $db->query("INSERT INTO neplan VALUES('$coal','$names','$planName','$subdomain','$domain','$price')");
    if (!$ex) {
        echo $db->lastErrorMsg();
    } else {
        session_start();
        $_SESSION['subdomain'] = $subdomain;
        $_SESSION['cvs'] = "Successfully";
        header('Location: create.php');
        exit;
    }
    echo $_SESSION['cvs'];
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hi, I'm Neilaffy and a Programmer</title>
    <link rel="stylesheet" href="dist/css/bootstrap.css" type="text/css" media="all" />
    <link rel="stylesheet" href="style.css" type="text/css" media="all" />
    <style type="text/css">
        .max {
            max-width: 600px;
            margin: 0 auto;
        }
        #modalForm {
            display: none;
        }
        .outlines:focus {
            border: 2px solid #198754;
        }
    </style>
</head>
<body class="p-30 max">
    <div class="my-3">
        <a class="btn btn-success fw-bold">
            Neilaffy App
        </a>
    </div>
    <div class="my-3 alert alert-success">
        <h1>Hello Everyone!</h1>
        <p>
            You can make plans here. Get easy free access.
        </p>
        <a class="btn btn-success fw-bold" onclick="opensModal(1)">
            ✓ New Plan
        </a>
    </div>
    <div id="modalForm">
        <h2>Create Plan</h2>
        <form action="" method="post">
            <div class="form-group mb-3">
                <label for="Name Plan" class="fw-bold mb-2">Name Plan</label>
                <input type="text" name="namePlan" class="form-control outlines p-2" placeholder="Name Plan" />
            </div>
            <div class="form-group mb-3">
                <label for="Plan Hosting" class="fw-bold mb-2">Plan Hosting</label>
                <select name="plan" id="startPlan" class="form-control outlines p-2" onchange="changing()">
                    <option value="Free">Free Plan / Years</option>
                    <option value="Plan1">CKP Portofolio Hosting </option>
                    <option value="New">New CKP Portofolio Hosting </option>
                </select>
            </div>
            <div class="mb-3">
                <input type="text" id="price" class="form-control outlines p-2" value="Ro.0" disabled />
            </div>
            <div class="form-group">
                <label for="Subdomain Name" class="fw-bold mb-2">Subdomain Name</label>
                <div class="input-group">
                    <input type="text" class="form-control outlines p-2" placeholder="Subdomain Name" aria-label="Recipient's username" aria-describedby="basic-addon2" name="subdomain">
                    <span class="input-group-text" id="basic-addon2">.neilaffy.web.id</span>
                </div>
            </div>
            <button type="submit" class="mt-3 btn fw-bold btn-success btn-md" name="continue">Continue</button>
        </form>
    </div>

    <?php
    $em = $_SESSION['success'];
    $stat = $db->query('SELECT * FROM neplan WHERE name LIKE "'.$em.'%" ORDER BY id DESC');
    $rows = $stat->fetchAll(PDO::FETCH_ASSOC);

    $stats = $db->prepare('SELECT * FROM users WHERE email = "'.$em.'"');
    $stats->execute();
    $data = $stats->fetchAll(\PDO::FETCH_ASSOC);

    foreach ($rows as $row) {
        $names = $row['name'];
        $ecp = explode("=", $names);
        if ($data[0]['email'] === $ecp[0] && $row['plan'] == "Plan1") {
            ?>
            <div class="my-3">
                <span class="w-100 alert alert-success fw-bold text-start btn-lg d-flex justify-content-between align-items-center">
                    <div class="m-0">
                        <?php echo $ecp[1]; ?>
                        <p style="font-size:14px;" class="m-0">
                            <?php echo $row['plan']; ?> - Plan
                            <br>
                            Domain: <?php echo $row['domain']; ?> | <?php echo $row['subdomain']; ?>
                             <br>
                            Disk Space: 0/41 MB
                        </p>
                    </div>
                    <div class="mx-1">
                        <button class="fw-bold btn btn-warning">Pending</button>
                    </div>
                </span>
                <div id="planModal">
                    <div class="my-2">
                        <a class="w-100 btn btn-success fw-bold text-start btn-lg d-flex justify-content-between align-items-center)">
                            <span>File Manager</span>
                        </a>
                    </div>
                    <div class="my-2">
                        <a class="w-100 btn btn-success fw-bold text-start btn-lg d-flex justify-content-between align-items-center)">
                            <span>Database</span>
                        </a>
                    </div>
                    <div class="my-2">
                        <a class="w-100 btn btn-success fw-bold text-start btn-lg d-flex justify-content-between align-items-center)">
                            <span>Addon Domain</span>
                        </a>
                    </div>
                </div>
            </div>
            <?php
}     
if($row['plan']=="Free"){
            ?>

            <div class="my-3">
                <span class="w-100 alert alert-success fw-bold text-start btn-lg d-flex justify-content-between align-items-center">
                    <div class="m-0">
                        <?php echo $ecp[1]; ?>
                        <p style="font-size:14px;" class="m-0">
                            <?php echo $row['plan']; ?> - Plan
                            <br>
                            Domain:<?php echo $row['subdomain']; ?>
                            <br>
                            Disk Space: 0/10 MB
                        </p>
                    </div>
                    <div class="mx-1">
                        <button class="fw-bold btn btn-warning">Pending</button>
                    </div>
                </span>
                <div id="planModal">
                    <div class="my-2">
                        <a class="w-100 btn btn-success fw-bold text-start btn-lg d-flex justify-content-between align-items-center)">
                            <span>File Manager</span>
                        </a>
                    </div>
                </div>
            </div>
            <?php
        }


    }



    ?>
    <div class="login mb-3">
        @2024 - 2025
    </div>
    <script type="text/javascript" charset="utf-8">
        var modalPlan = document.getElementById('planModal');
        var modalFrm = document.getElementById('modalForm');
        function opensModal(id) {
            if (id == 1) {
                modalFrm.style.display = "block";
            } else {
                console.log("No Plan");
            }
        }

        function changing() {
            var startPlanning = document.getElementById('startPlan').value;
            var host = document.getElementById('price');
            if (startPlanning == "Plan1") {
                host.value = "IDR 400,000/Years";
            } else if (startPlanning == "New") {
                host.value = "New Plan CKP Hosting";
            } else {
                host.value = "Rp.0";
            }
        }
    </script>
    <script src="dist/js/bootstrap.bundle.js" type="text/javascript" charset="utf-8"></script>
</body>
</html>
